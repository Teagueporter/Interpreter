//
// Created by Teagu on 10/25/2021.
//

#ifndef MAIN_CPP_INTERPRETER_H
#define MAIN_CPP_INTERPRETER_H
#include "Datalog.h"
#include "Database.h"
#include <algorithm>

class Interpreter{
private:
    Datalog datalogProgram;
    Database database;
public:
    Interpreter(Datalog myDatalog){
        this->datalogProgram = myDatalog;
    }

    //instead just make the relation here meaning slightly more code?
    void evaluateSchemes(){
        for(auto s : datalogProgram.schemesVector){
            database.addRelation(s.name, Header(s.getParamValues()));
        }

//        for(size_t i = 0; i < datalogProgram.schemesVector.size(); i++){
//            std::string newName = datalogProgram.schemesVector.at(i).getName();
//            Header newHeader;
//            for(size_t j = 0; i < datalogProgram.schemesVector.at(i).getParameters().size(); j++){
//                newHeader.addAttribute(datalogProgram.schemesVector.at(i).getParameters().at(j).getValue());
//            }
//            Relations newRelation(newHeader, newName);
//            database.addToDatabase(&newRelation);
//        }


    }
    void evaluateFacts(){
        for(auto f : datalogProgram.factsVector){
            std::string key = f.name;
            database.getMyMap()[key]->insertTuples(f.getParamValues());
        }
//        for(size_t i = 0; i < datalogProgram.factsVector.size(); i++){
//            std::string myName = datalogProgram.factsVector.at(i).getName();
//            Tuple myTup;
//            for(size_t j = 0; j < datalogProgram.schemesVector.at(i).getParameters().size(); j++){
//                myTup.addToTup(datalogProgram.schemesVector.at(i).getParameters().at(j).getValue());
//            }
//            database.addTupleToRelation(myName, myTup);
//        }
    }

    void evaluateQueries(){
        Relations r;
        for(size_t i = 0; i < datalogProgram.queriesVector.size(); i++){
            r = evaluatePredicate(datalogProgram.getQueriesVector().at(i));
            if(r.rsize() > 0){
                std::cout << datalogProgram.queriesVector.at(i).toString();
                std::cout << "? Yes(" << r.rsize() << ")";
                std::cout << r.toString();
            }
            else{
                std::cout << datalogProgram.queriesVector.at(i).toString();
                std::cout << "? No(" << r.rsize() << ")";
                std::cout << r.toString();
            }
        }
    }

    //TODO make a is seen function
    //TODO make a evaluate function that class evaluate schmes, facts, queries or just do schemes and facts in construtor

    Relations evaluatePredicate(const Predicate& p){
        std::vector<int> indexs;
        std::vector<std::string> names;

        Relations myRelation = *(database.getMyMap()[p.getName()]);

        for(size_t i = 0; i < p.getParameters().size(); i++){
            //TODO check if it is a constand
            if(p.getParameters().at(i).type == TokenType::STRING){
                myRelation = myRelation.select(i, p.getParameters().at(i).value);
            }

            else{
                int found = -1;
                    for(size_t j = 0; j < names.size(); j++){
                        if(p.parameters.at(i).value == names.at(j)){
                            found = j;
                            break;
                        }
                    }
                    if(found >= 0 ){
                        myRelation = myRelation.select(i, found);
                    }
                    else{
                        names.push_back(p.parameters.at(i).value);
                        indexs.push_back(i);
                    }
            }
        }
        myRelation = myRelation.project(indexs);
        myRelation = myRelation.rename(names);

        return myRelation;

    }

    std::string toString(){
        return database.toString();
    }

};
#endif //MAIN_CPP_INTERPRETER_H
