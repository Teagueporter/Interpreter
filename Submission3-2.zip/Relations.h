//
// Created by Teagu on 10/25/2021.
//

#ifndef MAIN_CPP_RELATIONS_H
#define MAIN_CPP_RELATIONS_H
#include <iostream>
#include <vector>
#include <set>
#include <sstream>
#include "Tuple.h"
#include "Header.h"

class Relations{
public:
    //Declaring variables
    std::string name;
    std::set<Tuple> tuple{};
    Header header;


    //Constructor for empty relation
    Relations(Header newHeader, std::string Rname){
        name = Rname;
        header = newHeader;
    }

    Relations() = default;


    void insertTuples(Tuple tup){
        tuple.insert(tup);
    }

    Relations select(int index, std::string value){
        //create new relation
        Relations newRelation(this->header, this->name);//**********************
        for(auto i : tuple){
            if(i.getValue(index) == value){
                newRelation.insertTuples(i);
            }
        }
        return newRelation;
    }

    Relations select(int index, int index1){
        Relations newRelation(this->header, this->name);
        for (auto i: tuple) {
            if (i.getValue(index) == i.getValue(index1)) {
                newRelation.insertTuples(i);
            }
        }
        return newRelation;
    }
    Relations project(std::vector<int> indexs){
        std::vector<std::string> newHeaders;
        for(auto i : indexs){
            newHeaders.push_back(this->header.attributes.at(i));
        }
        Relations newRelation(Header(newHeaders), this->name);
        for(auto t : tuple){
            Tuple myTuple;
            for(auto i : indexs){
                myTuple.addToTup(t.getValue(i));
            }
            newRelation.insertTuples(myTuple);
        }
        return newRelation;

    }
    Relations rename(std::vector<std::string> attributes){
        //iterate through everything and swap positions
        Header myHeader = Header(attributes);
        header = myHeader;
        return *this;
    }

    //possible getters and setters
    std::string getName(){
        return name;
    }
    void setName(std::string newName){
        name = newName;
    }

    int rsize(){
        return tuple.size();
    }


    //toString to print out the Tuples
    std::string toString(){
        std::stringstream oss;
        bool isSizeZero = false;
        if(this->rsize() >= 0) {
            for (auto param : tuple) {
                oss << std::endl;
                oss << "  ";
                for (size_t i = 0; i < header.getHeaderSize(); i++) {
                    oss << header.getAttribute(i) << "=" << param.getValue(i);
                    if (i != header.getHeaderSize() - 1) {
                        oss << ", ";
                    }
                }
                if(param.getSize() > 0){
                    isSizeZero = true;
                }
            }
        }
        if(isSizeZero == true){oss << std::endl;}

        return oss.str();
    }




};

#endif //MAIN_CPP_RELATIONS_H
