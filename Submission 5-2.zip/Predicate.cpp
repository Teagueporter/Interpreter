//
// Created by Teagu on 9/28/2021.
//

#include "Predicate.h"
