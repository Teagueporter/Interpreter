//
// Created by Teagu on 9/28/2021.
//

#ifndef MAIN_CPP_PREDICATE_H
#define MAIN_CPP_PREDICATE_H

#include <vector>
#include "Parameter.h"

class Predicate {
public:
    std::string name;
    std::vector<Parameter> parameters;
    Predicate() = default;
    Predicate(std::string n) {name = n;}
    Predicate(std::string n, std::string p){name = n; parameters.push_back(p);}

    void addToParameterVector(std::string input){
        parameters.push_back(input);
    }

    const std::vector<Parameter> &getParameters() const {
        return parameters;
    }



    std::string toString(){
        std::stringstream oss;
        oss << name;
        oss << "(";
        for(size_t i = 0; i < parameters.size(); ++i){
            oss << parameters.at(i).toString();
            if(i != parameters.size() - 1){
                oss << ",";
            }
        }
        oss << ")";
        return oss.str();
    }
//    std::string setParam(){
//        for(size_t i = 0; i < parameters.size(); ++i){
//            domainParameters.at(i) = parameters.at(i);
//    }
};


#endif //MAIN_CPP_PREDICATE_H
