#include "Lexer.h"
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    string inputStream = argv[1];
    ifstream ifs (inputStream, ifstream::in);

    char c;
    string file;

    while(ifs.peek() != EOF){
        c = ifs.get();
        file += c;
    }

    cout << file << endl;


    Lexer* lexer = new Lexer();

    // TODO
    lexer->Run(file);
    cout << lexer->toStringLexar();


    delete lexer;

    return 0;
}