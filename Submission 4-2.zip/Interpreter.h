//
// Created by Teagu on 10/25/2021.
//

#ifndef MAIN_CPP_INTERPRETER_H
#define MAIN_CPP_INTERPRETER_H
#include "Datalog.h"
#include "Database.h"
#include <algorithm>

class Interpreter{
private:
    Datalog datalogProgram;
    Database database;
    bool didTupsChange = false;
    size_t totalTupCount = 0;
public:
    Interpreter(Datalog myDatalog){
        this->datalogProgram = myDatalog;
    }
    void evaluateSchemes(){
        for(auto s : datalogProgram.schemesVector){
            database.addRelation(s.name, Header(s.getParamValues()));
        }
    }
    void evaluateFacts(){
        for(auto f : datalogProgram.factsVector){
            std::string key = f.name;
            database.getMyMap()[key]->insertTuples(f.getParamValues());
        }
    }
    void evaluateAllRules(){
        cout << "Rule Evaluation" << endl;
        bool changed = true;
        size_t prevTups = database.countTups();
        size_t numTups = 0;
        size_t numPass = 0;
        while(changed){
            evaluateRules();

            numTups = database.countTups();
            if(prevTups == numTups){
                changed = false;
            }
            prevTups = numTups;
            numTups = 0;
            numPass++;
        }
        cout << "\nSchemes populated after " << std::to_string(numPass) << " passes through the Rules." << endl;

    }
    void evaluateRules(){
        didTupsChange = false;
        for(size_t i = 0; i < datalogProgram.rulesVector.size(); i++){
            std::vector<Relations*> vectorR;
            for(size_t j = 0; j < datalogProgram.rulesVector.at(i).bodyPredicates.size(); j++){
                vectorR.push_back(evaluatePredicate(datalogProgram.rulesVector.at(i).bodyPredicates.at(j)));
            }
            std::vector<int> vectorI;
            Relations* newR;
            if(vectorR.size() > 1){
                newR = vectorR.at(0);
                for(size_t k = 1; k < vectorR.size(); k++){
                    newR = newR->join(vectorR.at(k));
                }
            }
            else{
                newR = vectorR.at(0);
            }
            for(size_t hp = 0; hp < datalogProgram.rulesVector.at(i).headPredicate.parameters.size(); hp++){
                for(size_t nrp = 0; nrp < newR->header.attributes.size(); nrp++){
                    if(datalogProgram.rulesVector.at(i).headPredicate.parameters.at(hp).getValue() == newR->header.attributes.at(nrp)){
                        vectorI.push_back(nrp);
                    }
                }
            }

            newR = newR->project(vectorI);
            newR = newR->rename(database.getMyMap()[datalogProgram.rulesVector.at(i).headPredicate.name]->header.attributes);

            cout << datalogProgram.rulesVector.at(i).toString()  << "." << endl;

            string printout = datalogProgram.rulesVector.at(i).toString();

            if(database.getMyMap()[datalogProgram.rulesVector.at(i).headPredicate.name]->tuple.size() > 0){
                std::set<Tuple> newT = database.getMyMap()[datalogProgram.rulesVector.at(i).headPredicate.name]->insertTuples(newR);
                if(newT.size() > 0){
                    cout << Relations(newR->header, newT).toString();
                }
            }
//            else{
//                database.addRelation(datalogProgram.rulesVector.at(i).headPredicate.name, newR);
//                cout << newR->toString();
//            }
//            if(database.getMyMap()[datalogProgram.rulesVector.at(i).headPredicate.name]->tuple.size() != count){
//                didTupsChange = true;
//            }

        }

        //Fix something her so that it prints out more rules
//        for(size_t i = 0; i < datalogProgram.rulesVector.size(); i++){
//            cout << datalogProgram.rulesVector.at(i).toString() << "." << endl;
//        }

    }

    bool isDidTupsChange() const {
        return didTupsChange;
    }


    size_t getTotalTupCount(){
        totalTupCount = database.countTups();
        return totalTupCount;
    }

    void evaluateQueries(){
        Relations* r;
        for(size_t i = 0; i < datalogProgram.queriesVector.size(); i++){
            r = evaluatePredicate(datalogProgram.getQueriesVector().at(i));
            if(r->rsize() > 0){
                std::cout << datalogProgram.queriesVector.at(i).toString();
                std::cout << "? Yes(" << r->rsize() << ")";
                cout << "\n";
                std::cout << r->toString();
            }
            else{
                std::cout << datalogProgram.queriesVector.at(i).toString();
                std::cout << "? No";
                std::cout << r->toString() << endl;
            }
        }
    }

    Relations* evaluatePredicate(const Predicate& p){
        std::vector<int> indexs;
        std::vector<std::string> names;

        Relations* myRelation = (database.getMyMap()[p.getName()]);

        for(size_t i = 0; i < p.getParameters().size(); i++){
            //TODO check if it is a constand
            if(p.getParameters().at(i).type == TokenType::STRING){
                myRelation = myRelation->select(i, p.getParameters().at(i).value);
            }

            else{
                int found = -1;
                    for(size_t j = 0; j < names.size(); j++){
                        if(p.parameters.at(i).value == names.at(j)){
                            found = j;
                            break;
                        }
                    }
                    if(found >= 0 ){
                        myRelation = myRelation->select(i, found);
                    }
                    else{
                        names.push_back(p.parameters.at(i).value);
                        indexs.push_back(i);
                    }
            }
        }
        myRelation = myRelation->project(indexs);
        myRelation = myRelation->rename(names);

        return myRelation;

    }

    std::string toString(){
        return database.toString();
    }

};
#endif //MAIN_CPP_INTERPRETER_H
